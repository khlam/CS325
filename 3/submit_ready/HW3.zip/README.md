Kin-Ho Lam Summer 2017 
CS 325 Assignment 3
Make Change Python


USE COMMAND "make change" TO RUN.

Run the following makefile commands in terminal.
This code is tested and working on flip.engr.oregonstate.edu

> Commands  			   > Description

make change .............. Cleans the working directory, generates amount.txt with default values, runs change.py, directs output solution to change.txt

make run ................. If you alreay have amount.txt in the same directory, running this command will execute the script.

make clean ............... Cleans the directory (Delete all .txt files)
